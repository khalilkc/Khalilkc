// تعريف المواد الدراسية والمعاملات
const subjects = [
    { name: "اللغة العربية", coefficient: 4 },
    { name: "اللغة الفرنسية", coefficient: 2 },
    { name: "الرياضيات", coefficient: 5 },
    { name: "علوم الحياة والأرض", coefficient: 3 },
    { name: "التربية التشكيلية", coefficient: 1 },
    { name: "الفيزياء والكيمياء", coefficient: 4 },
    { name: "الرياضة", coefficient: 1 },
    { name: "التكنولوجيا", coefficient: 2 },
    { name: "اللغة الإنجليزية", coefficient: 2 },
    { name: "التربية الإسلامية", coefficient: 2 },
    { name: "الإجتماعيات", coefficient: 3 }
];

// تحميل المواد في الجدول تلقائيًا
const gradesTable = document.getElementById("grades-table").querySelector("tbody");

subjects.forEach(subject => {
    const row = document.createElement("tr");
    row.innerHTML = `
        <td>${subject.name}</td>
        <td>${subject.coefficient}</td>
        <td><input type="number" min="0" max="20" step="0.01" data-subject="${subject.name}" data-type="assignment1"></td>
        <td><input type="number" min="0" max="20" step="0.01" data-subject="${subject.name}" data-type="assignment2"></td>
        <td><input type="number" min="0" max="20" step="0.01" data-subject="${subject.name}" data-type="exam"></td>
    `;
    gradesTable.appendChild(row);
});

// حفظ بيانات الطالب
document.getElementById("save-student").addEventListener("click", () => {
    const name = document.getElementById("student-name").value;
    if (name) {
        document.getElementById("student-name-display").textContent = name;
        alert(`تم حفظ بيانات الطالب: ${name}`);
    } else {
        alert("الرجاء إدخال اسم الطالب!");
    }
});

// حساب المعدل العام
document.getElementById("calculate-average").addEventListener("click", () => {
    let totalPoints = 0;
    let totalCoefficients = 0;

    subjects.forEach(subject => {
        const assignment1 = parseFloat(
            document.querySelector(`input[data-subject="${subject.name}"][data-type="assignment1"]`).value || 0
        );
        const assignment2 = parseFloat(
            document.querySelector(`input[data-subject="${subject.name}"][data-type="assignment2"]`).value || 0
        );
        const exam = parseFloat(
            document.querySelector(`input[data-subject="${subject.name}"][data-type="exam"]`).value || 0
        );

        // حساب معدل المادة
        const subjectAverage = (assignment1 * 0.25 + assignment2 * 0.25 + exam * 0.5);
        totalPoints += subjectAverage * subject.coefficient;
        totalCoefficients += subject.coefficient;
    });

    // حساب المعدل العام
    const overallAverage = (totalPoints / totalCoefficients).toFixed(2);
    document.getElementById("overall-average").textContent = overallAverage;
});